<footer class="px-[30px] lg:px-32 py-8 bg-[#444444] flex flex-col lg:flex-row justify-between">
    <p class="text-white text-xs mb-6 lg:mb-0">Lorem Ipsum Dolor Sit Amet - Lorem Ipsum dolor sit amet consectetur adipiscing elit</p>
    <p class="text-white text-xs">© {{ now()->year }} - PT Surya Golden Energy</p>
</footer>