<div>
    <div class="">
        <div>
            <img src="{{asset('/images/product1.png')}}" class="w-full object-cover"/>
        </div>
        <div class="mb-4">
            <h4 class="font-[#232321] text-base lg:text-[24px] font-black">ONFLD. AXIL HOODIE SPORT HIJAB</h4>
        </div>
        <div class="bg-[#232321] py-2 px-4 rounded-[8px] text-center text-white">
            <span class="leading-none text-xs lg:text-sm font-black">View Product - $125</span>
        </div>
    </div>
</div>