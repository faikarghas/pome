<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="8" fill="#232321"/>
    <path d="M18.1668 17.1057H30.8947V29.8336M30.0108 17.9895L17.1061 30.8942" stroke="#E7E7E3" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
    